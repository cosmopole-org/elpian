use bevy::prelude::*;
use bevy_json_ui::{JsonScene, JsonScenePlugin};

fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .add_plugins(JsonScenePlugin)
        .add_systems(Startup, setup)
        .run();
}

fn setup(mut commands: Commands, asset_server: Res<AssetServer>) {
    // Load the JSON scene
    let json_scene = JsonScene::load_from_file("examples/ui_example.json")
        .expect("Failed to load UI scene");

    // Spawn the UI elements from JSON
    json_scene
        .spawn_ui(&mut commands, &asset_server)
        .expect("Failed to spawn UI");

    println!("UI Demo loaded successfully!");
    println!("The UI is defined entirely in examples/ui_example.json");
}
